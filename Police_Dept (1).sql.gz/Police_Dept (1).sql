-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Mar 11, 2024 at 04:57 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `Police_Dept`
--

-- --------------------------------------------------------

--
-- Table structure for table `Cases`
--

CREATE TABLE `Cases` (
  `Case_id` int(5) NOT NULL,
  `Case_type` varchar(20) DEFAULT NULL,
  `Case_status` varchar(10) DEFAULT NULL,
  `Criminal_name` varchar(20) DEFAULT NULL,
  `Date_of_crime` varchar(10) DEFAULT NULL,
  `Staff_id` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `Cases`
--

INSERT INTO `Cases` (`Case_id`, `Case_type`, `Case_status`, `Criminal_name`, `Date_of_crime`, `Staff_id`) VALUES
(1, 'Murder', 'Active', 'Bharadwaj', '11/09/2001', 'A100'),
(2, 'Rape', 'Closed', 'Chethan', '14/02.2024', 'A101');

-- --------------------------------------------------------

--
-- Table structure for table `Login`
--

CREATE TABLE `Login` (
  `Staff_id` varchar(10) NOT NULL,
  `Password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `Login`
--

INSERT INTO `Login` (`Staff_id`, `Password`) VALUES
('A100', 'nigga1'),
('A101', 'nigga2');

-- --------------------------------------------------------

--
-- Table structure for table `Staff`
--

CREATE TABLE `Staff` (
  `Staff_id` varchar(10) NOT NULL,
  `Staff_name` varchar(30) DEFAULT NULL,
  `Designation` varchar(20) DEFAULT NULL,
  `DOJ` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `Staff`
--

INSERT INTO `Staff` (`Staff_id`, `Staff_name`, `Designation`, `DOJ`) VALUES
('A100', 'Achyuth', 'Superindent', '11/09/2001'),
('A101', 'Ashwin', 'ACP', '11/09/2001');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Cases`
--
ALTER TABLE `Cases`
  ADD PRIMARY KEY (`Case_id`),
  ADD KEY `Staff_id` (`Staff_id`);

--
-- Indexes for table `Login`
--
ALTER TABLE `Login`
  ADD PRIMARY KEY (`Staff_id`);

--
-- Indexes for table `Staff`
--
ALTER TABLE `Staff`
  ADD PRIMARY KEY (`Staff_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Cases`
--
ALTER TABLE `Cases`
  MODIFY `Case_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `Cases`
--
ALTER TABLE `Cases`
  ADD CONSTRAINT `Cases_ibfk_1` FOREIGN KEY (`Staff_id`) REFERENCES `Staff` (`Staff_id`) ON DELETE CASCADE;

--
-- Constraints for table `Login`
--
ALTER TABLE `Login`
  ADD CONSTRAINT `Login_ibfk_1` FOREIGN KEY (`Staff_id`) REFERENCES `Staff` (`Staff_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
